package p2pserver;

public class Test {
    
    public static void main(String[] args) {
    Server.Start(5001);
    }
}
